# SharkX Tuner v1.1 FREE — GitHub Actions

This project is prepared to build the Android APK on GitHub Actions, so a PC is not required for the build itself.

## Build the APK

1. Create a GitHub repository.
2. Upload the contents of this project (the files inside this folder, not the ZIP file itself).
3. Open **Actions** in the repository.
4. Select **Build SharkX Tuner APK**.
5. Press **Run workflow**.
6. When the workflow finishes, open the completed run.
7. Under **Artifacts**, download `SharkXTuner-v1.1-FREE-debug`.
8. Inside the downloaded artifact is `app-debug.apk`.

The workflow uses Java 17, Android SDK 35 and Gradle 8.7, matching the project's Android Gradle Plugin 8.6.1 setup.

## Notes

- The generated debug APK is intended for testing/installing on Android.
- This workflow does not create a Play Store-signed release. A production release should use a private signing key stored in GitHub Actions secrets.
- The app's Shizuku, overlay and Android permission behavior still depends on the target phone and its Android version.
