# SharkX Tuner 🦈 — Free Edition v1.1 (Ellen Joe Red/Black)

Versión gratuita actualizada con una interfaz rojo/negro y temática Ellen Joe.

## Acceso
- Pantalla de entrada única.
- Contraseña inicial: `SHARK15710`.
- Botón de ojo para mostrar/ocultar la contraseña.
- No hay inicio de sesión con cuentas ni Premium en esta edición.

## Funciones reales
- DPI editable.
- Resolución editable (ancho × alto).
- Aplicación real mediante `wm density` y `wm size` a través de Shizuku.
- Restauración mediante `wm density reset` y `wm size reset`.
- Estado real de Shizuku.
- Estado real de la pantalla.
- Panel flotante con los valores configurados.
- Lanzador de Free Fire / Free Fire MAX.

## Cambios de esta revisión
- Tema completo negro/rojo.
- Logo reemplazado por arte de Ellen Joe.
- Ellen Joe añadida a login, dashboard y panel flotante.
- Valores iniciales alineados con la interfaz: DPI 440, resolución 2400×1080.
- Los valores solo se guardan después de aplicar correctamente.
- Si falla la segunda parte de un cambio de pantalla, se intenta recuperar el override anterior en vez de hacer un reset ciego.
- El panel flotante usa tamaños en dp y evita duplicarse.
- Se mantienen las comprobaciones de permisos y el estado real de Shizuku.
- Se eliminaron funciones falsas de optimización/pantalla completa.

## Importante
SharkX Tuner no usa root ni intenta saltarse permisos de Android. DPI/resolución solo se aplican cuando Shizuku está activo y autorizado.

La contraseña está almacenada como SHA-256, pero al ser una contraseña fija incluida en la app, esta edición NO debe considerarse un sistema de seguridad fuerte frente a ingeniería inversa.

## Dependencia
Se usa `dev.rikka.shizuku:api:13.1.5`.

## GitHub Actions build

This copy includes `.github/workflows/build-apk.yml`. Upload the project contents to GitHub, then run **Actions → Build SharkX Tuner APK → Run workflow**. The finished `app-debug.apk` is published as a workflow artifact.
See `GITHUB_ACTIONS_GUIDE.md` for the phone-only steps.
