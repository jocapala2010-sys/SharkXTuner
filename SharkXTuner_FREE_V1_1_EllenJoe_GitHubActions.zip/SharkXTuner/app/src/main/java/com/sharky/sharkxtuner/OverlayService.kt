package com.sharky.sharkxtuner

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var launcherView: View? = null
    private var panelView: View? = null
    private val prefs by lazy { getSharedPreferences("sharkx_settings", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, notification())
        showLauncher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        removeView(panelView)
        removeView(launcherView)
        panelView = null
        launcherView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showLauncher() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (launcherView != null) return

        val button = TextView(this).apply {
            text = "🦈"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190, 8, 35))
            setPadding(12, 12, 12, 12)
            contentDescription = "Abrir SharkX Tuner"
            setOnClickListener { showPanel() }
        }

        val params = WindowManager.LayoutParams(
            dp(58), dp(58),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            x = dp(12)
        }

        launcherView = button
        windowManager?.addView(button, params)
    }

    private fun showPanel() {
        if (panelView != null) return
        val d = prefs.getInt("dpi", 440)
        val w = prefs.getInt("width", 2400)
        val h = prefs.getInt("height", 1080)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(17, 8, 13))
        }
        val art = ImageView(this).apply {
            setImageResource(R.drawable.ellen_joe_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Ellen Joe"
        }
        panel.addView(art, LinearLayout.LayoutParams(-1, dp(120)).apply { setMargins(0, 0, 0, dp(6)) })
        panel.addView(tv("🦈  SharkX Tuner", 22f))
        panel.addView(tv("Ellen Joe  •  Sharky 🦈  •  Free Fire", 13f, Color.rgb(255, 106, 125)))

        val dpi = field("DPI", d.toString())
        val width = field("Ancho", w.toString())
        val height = field("Alto", h.toString())
        panel.addView(dpi)
        panel.addView(width)
        panel.addView(height)

        val status = tv("", 13f, Color.LTGRAY)
        panel.addView(status)

        val apply = Button(this).apply {
            text = "✓ Aplicar"
            setOnClickListener {
                val nd = dpi.text.toString().toIntOrNull()
                val nw = width.text.toString().toIntOrNull()
                val nh = height.text.toString().toIntOrNull()
                if (nd == null || nw == null || nh == null || nd !in 100..1200 || nw !in 240..8000 || nh !in 240..8000) {
                    status.text = "✗ Valores fuera de rango"
                    return@setOnClickListener
                }
                prefs.edit().putInt("dpi", nd).putInt("width", nw).putInt("height", nh).apply()
                val result = ShizukuShell.applyDisplay(nd, nw, nh)
                status.text = if (result.isSuccess) "🟢 Aplicado: $nd DPI • ${nw}×$nh" else "🔴 ${result.exceptionOrNull()?.message}"
            }
        }
        panel.addView(apply, smallLp())

        val reset = Button(this).apply {
            text = "↩ Restaurar"
            setOnClickListener {
                val result = ShizukuShell.resetDisplay()
                status.text = if (result.isSuccess) "🟢 Pantalla restaurada" else "🔴 ${result.exceptionOrNull()?.message}"
            }
        }
        panel.addView(reset, smallLp())

        val close = Button(this).apply {
            text = "Cerrar"
            setOnClickListener { removePanel() }
        }
        panel.addView(close, smallLp())

        val scroll = ScrollView(this).apply { addView(panel) }
        val params = WindowManager.LayoutParams(
            dp(330), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        panelView = scroll
        try {
            windowManager?.addView(scroll, params)
        } catch (t: Throwable) {
            panelView = null
            Toast.makeText(this, "No se pudo abrir el panel: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun removePanel() {
        removeView(panelView)
        panelView = null
    }

    private fun removeView(view: View?) {
        if (view == null) return
        try { windowManager?.removeViewImmediate(view) } catch (_: Throwable) { }
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setSingleLine(true)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = getDrawable(R.drawable.bg_input)
        layoutParams = smallLp()
    }

    private fun tv(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun smallLp() = LinearLayout.LayoutParams(-1, WindowManager.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, dp(6), 0, 0)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("sharkx_overlay", "SharkX Tuner", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification = NotificationCompat.Builder(this, "sharkx_overlay")
        .setSmallIcon(android.R.drawable.ic_menu_manage)
        .setContentTitle("SharkX Tuner")
        .setContentText("Panel flotante activo")
        .setOngoing(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .build()
}
