package com.sharky.sharkxtuner

import android.content.Context
import java.security.MessageDigest

/** Local gate for the FREE edition. The password is intentionally fixed for this build. */
class SecurityStore(context: Context) {
    private val prefs = context.getSharedPreferences("shark_security", Context.MODE_PRIVATE)

    init {
        // FREE edition: always restore the fixed entry password on each install/update.
        prefs.edit().putString(KEY_PASSWORD_HASH, PASSWORD_HASH).apply()
    }

    fun verifyPassword(value: String): Boolean = sha256(value) == prefs.getString(KEY_PASSWORD_HASH, PASSWORD_HASH)

    private fun sha256(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_PASSWORD_HASH = "password_hash"
        private const val PASSWORD_HASH = "ec866ae7085a1fefda8157ac87ee6161a19900ebf45fb7a84110bd5a28ed10e3"
    }
}
