package com.sharky.sharkxtuner

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var security: SecurityStore
    private lateinit var status: TextView
    private lateinit var overlayButton: Button
    private var pendingOverlayStart = false

    private val red = Color.rgb(255, 23, 56)
    private val redSoft = Color.rgb(255, 106, 125)
    private val text = Color.rgb(255, 242, 244)
    private val muted = Color.rgb(191, 166, 172)
    private val bg = Color.rgb(5, 3, 7)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        security = SecurityStore(this)
        requestNotificationPermissionIfNeeded()
        showLogin()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
        if (::overlayButton.isInitialized) {
            updateOverlayButton()
            if (pendingOverlayStart && Settings.canDrawOverlays(this)) {
                pendingOverlayStart = false
                startOverlay()
            }
        }
    }

    private fun showLogin() {
        val root = base()
        root.gravity = Gravity.CENTER

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            background = getDrawable(R.drawable.bg_panel)
        }
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(18, 12, 18, 12) })

        val art = ImageView(this).apply {
            setImageResource(R.drawable.ellen_joe)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.88f
            contentDescription = "Ellen Joe"
        }
        card.addView(art, LinearLayout.LayoutParams(-1, 190).apply { setMargins(0, 0, 0, 10) })

        card.addView(tv("SHARKX TUNER", 30f, text).apply { gravity = Gravity.CENTER })
        card.addView(tv("v1.1 FREE  •  ELLEN JOE", 14f, redSoft).apply { gravity = Gravity.CENTER })
        card.addView(tv("ACCESO SEGURO", 13f, muted).apply { gravity = Gravity.CENTER; setPadding(0, 12, 0, 8) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val input = EditText(this).apply {
            hint = "Ingresa la contraseña"
            hintTextColor = muted
            setTextColor(text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = getDrawable(R.drawable.bg_input)
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))

        val eye = Button(this).apply {
            text = "👁"
            textSize = 18f
            contentDescription = "Mostrar u ocultar contraseña"
            setTextColor(text)
            background = getDrawable(R.drawable.bg_dark_button)
            setOnClickListener {
                val pos = input.selectionStart.coerceAtLeast(0)
                val isPassword = (input.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0
                input.inputType = if (isPassword) InputType.TYPE_CLASS_TEXT else
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                input.setSelection(pos.coerceAtMost(input.text.length))
            }
        }
        inputRow.addView(eye, LinearLayout.LayoutParams(58, -2).apply { setMargins(8, 0, 0, 0) })
        card.addView(inputRow, lp(0, 10))

        val unlock = Button(this).apply {
            text = "🔓  ENTRAR"
            setTextColor(Color.WHITE)
            background = getDrawable(R.drawable.bg_button)
            setOnClickListener {
                if (security.verifyPassword(input.text.toString())) {
                    hideKeyboard(input)
                    showDashboard()
                } else {
                    input.error = "Contraseña incorrecta"
                    input.selectAll()
                }
            }
        }
        card.addView(unlock, lp(0, 12))
        card.addView(tv("Ellen Joe × Sharky 🦈\nDPI • Resolución • Shizuku • Panel flotante", 13f, muted).apply { gravity = Gravity.CENTER })
        card.addView(tv("Creado por Sharky 🦈  •  SharkX Tuner", 12f, redSoft).apply { gravity = Gravity.CENTER })

        setContentView(root)
    }

    private fun showDashboard() {
        val root = base()
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 28)
        }
        scroll.addView(content)
        root.addView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val avatar = ImageView(this).apply { setImageResource(R.drawable.ellen_joe_avatar); scaleType = ImageView.ScaleType.CENTER_CROP }
        header.addView(avatar, LinearLayout.LayoutParams(62, 62).apply { setMargins(0, 0, 12, 0) })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(tv("SharkX Tuner", 26f, text))
        titleBox.addView(tv("v1.1 FREE  •  ELLEN JOE", 13f, redSoft))
        header.addView(titleBox)
        content.addView(header)

        val displayCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            background = getDrawable(R.drawable.bg_panel)
        }
        content.addView(displayCard, lp(0, 16))
        displayCard.addView(tv("🎮 Ajuste de pantalla", 20f, text))
        displayCard.addView(tv("Los cambios reales requieren Shizuku autorizado.", 13f, muted))

        val prefs = getSharedPreferences("sharkx_settings", MODE_PRIVATE)
        val dpi = numberInput("DPI", prefs.getInt("dpi", 440).toString())
        val width = numberInput("Ancho (px)", prefs.getInt("width", 2400).toString())
        val height = numberInput("Alto (px)", prefs.getInt("height", 1080).toString())
        displayCard.addView(dpi, lp())
        displayCard.addView(width, lp())
        displayCard.addView(height, lp())

        val apply = actionButton("✓  APLICAR DPI + RESOLUCIÓN") {
            val d = dpi.text.toString().toIntOrNull()
            val w = width.text.toString().toIntOrNull()
            val h = height.text.toString().toIntOrNull()
            if (d == null || w == null || h == null || d !in 100..1200 || w !in 240..8000 || h !in 240..8000) {
                toast("Revisa los valores: DPI 100–1200 y tamaño 240–8000.")
                return@actionButton
            }
            val result = ShizukuShell.applyDisplay(d, w, h)
            if (result.isSuccess) {
                prefs.edit().putInt("dpi", d).putInt("width", w).putInt("height", h).apply()
                toast("✓ Aplicado: $d DPI • ${w}×$h")
            } else toast("✗ ${result.exceptionOrNull()?.message ?: "No se pudo aplicar"}")
            updateStatus()
        }
        displayCard.addView(apply, lp())

        val reset = actionButton("↩  RESTAURAR SISTEMA") {
            val result = ShizukuShell.resetDisplay()
            if (result.isSuccess) {
                prefs.edit().remove("dpi").remove("width").remove("height").apply()
                toast("✓ Pantalla restaurada")
            } else toast("✗ ${result.exceptionOrNull()?.message ?: "No se pudo restaurar"}")
            updateStatus()
        }
        displayCard.addView(reset, lp())

        val state = actionButton("◉  VER ESTADO REAL") {
            val result = ShizukuShell.getDisplayState()
            toast(result.getOrElse { it.message ?: "No disponible" })
        }
        displayCard.addView(state, lp())

        val shizuku = actionButton("🔗  AUTORIZAR SHIZUKU") {
            ShizukuShell.requestPermission()
            toast(if (Shizuku.pingBinder()) "Acepta el permiso de SharkX Tuner en Shizuku." else "Abre Shizuku y vuelve a intentar.")
            updateStatus()
        }
        displayCard.addView(shizuku, lp())

        status = tv("", 14f, muted)
        displayCard.addView(status, lp())
        updateStatus()

        overlayButton = actionButton("", ::handleOverlay)
        content.addView(overlayButton, lp(0, 16))
        updateOverlayButton()

        content.addView(actionButton("🎮  ABRIR FREE FIRE") { launchFreeFire() }, lp())

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            background = getDrawable(R.drawable.bg_panel)
        }
        content.addView(info, lp(0, 16))
        info.addView(tv("🛡️ Estado de funciones", 18f, text))
        info.addView(tv("🟢 DPI y resolución: comandos reales mediante Shizuku\n🟢 Restaurar: comandos reales de Android\n🟢 Panel flotante: requiere permiso de superposición\n🟢 Lanzador de Free Fire: abre el juego si está instalado\n⚪ Sin optimizadores falsos ni funciones que solo simulen cambios", 14f, muted))
        info.addView(tv("\nSharkX Tuner no usa root ni intenta saltarse permisos de Android.", 13f, redSoft))

        content.addView(tv("\nELLEN JOE\nSharkX Tuner v1.1 FREE\nCreado por Sharky 🦈", 14f, redSoft).apply { gravity = Gravity.CENTER })
        setContentView(root)
    }

    private fun handleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            pendingOverlayStart = true
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            } else Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        } else startOverlay()
    }

    private fun startOverlay() {
        try {
            val serviceIntent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
            toast("🦈 Panel flotante activado")
        } catch (e: Throwable) { toast("No se pudo iniciar el panel: ${e.message ?: "error"}") }
    }

    private fun updateOverlayButton() {
        if (::overlayButton.isInitialized) {
            overlayButton.text = if (Settings.canDrawOverlays(this)) "🎈  PANEL FLOTANTE • LISTO" else "🎈  ACTIVAR PANEL FLOTANTE"
        }
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        status.text = if (ShizukuShell.isReady()) "🟢 Shizuku: conectado y autorizado" else "🟠 Shizuku: falta conectar o autorizar"
    }

    private fun launchFreeFire() {
        val pm = packageManager
        val intent = pm.getLaunchIntentForPackage("com.dts.freefireth") ?: pm.getLaunchIntentForPackage("com.dts.freefiremax")
        if (intent != null) startActivity(intent) else toast("Free Fire / Free Fire MAX no está instalado.")
    }

    private fun numberInput(label: String, value: String): EditText = EditText(this).apply {
        hint = label
        setText(value)
        setTextColor(text)
        hintTextColor = muted
        inputType = InputType.TYPE_CLASS_NUMBER
        background = getDrawable(R.drawable.bg_input)
        setSingleLine(true)
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        background = getDrawable(R.drawable.bg_button)
        minHeight = 54
        setOnClickListener { action() }
    }

    private fun base() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.drawable.bg_root) }

    private fun tv(s: String, size: Float, color: Int) = TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(0, 6, 0, 6) }

    private fun lp(width: Int = -1, top: Int = 10) = LinearLayout.LayoutParams(width, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0, top, 0, 0) }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun hideKeyboard(v: View) { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0) }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2001)
        }
    }
}
