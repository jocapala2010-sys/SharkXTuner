package com.sharky.sharkxtuner

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.regex.Pattern

object ShizukuShell {
    const val PERMISSION_REQUEST = 1001

    fun isReady(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder()) return
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(PERMISSION_REQUEST)
        } catch (_: Throwable) { }
    }

    fun run(command: String): Result<String> {
        if (!isReady()) return Result.failure(IllegalStateException("Shizuku no está conectado o autorizado."))
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val out = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            val code = process.waitFor()
            if (code == 0) Result.success(out.trim()) else Result.failure(IllegalStateException(err.ifBlank { "El comando falló (código $code)." }))
        } catch (t: Throwable) { Result.failure(t) }
    }

    fun applyDisplay(dpi: Int, width: Int, height: Int): Result<String> {
        require(dpi in 100..1200 && width in 240..8000 && height in 240..8000)
        val oldDensity = run("wm density").getOrNull()
        val oldSize = run("wm size").getOrNull()
        val densityCommand = "wm density $dpi"
        val sizeCommand = "wm size ${width}x${height}"

        val density = run(densityCommand)
        if (density.isFailure) return density
        val size = run(sizeCommand)
        if (size.isFailure) {
            rollback(oldDensity, oldSize)
            return Result.failure(IllegalStateException("No se pudo aplicar la resolución; se intentó restaurar el estado anterior."))
        }
        return Result.success("DPI $dpi • ${width}×$height")
    }

    fun resetDisplay(): Result<String> {
        val density = run("wm density reset")
        val size = run("wm size reset")
        return if (density.isSuccess && size.isSuccess) Result.success("Restaurado")
        else Result.failure(IllegalStateException("No se pudo restaurar completamente la pantalla. Revisa Shizuku."))
    }

    fun getDisplayState(): Result<String> {
        val size = run("wm size")
        val density = run("wm density")
        if (size.isFailure || density.isFailure) return Result.failure(IllegalStateException("Shizuku no está disponible."))
        return Result.success("Tamaño: ${size.getOrNull()}\nDensidad: ${density.getOrNull()}")
    }

    private fun rollback(oldDensity: String?, oldSize: String?) {
        val densityOverride = extract(oldDensity, "Override density:\\s*(\\d+)")
        val sizeOverride = extract(oldSize, "Override size:\\s*(\\d+x\\d+)")
        if (densityOverride != null) run("wm density $densityOverride") else run("wm density reset")
        if (sizeOverride != null) run("wm size $sizeOverride") else run("wm size reset")
    }

    private fun extract(value: String?, regex: String): String? {
        if (value.isNullOrBlank()) return null
        val m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE).matcher(value)
        return if (m.find()) m.group(1) else null
    }
}
